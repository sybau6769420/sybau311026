@echo off
chcp 65001 > nul
setlocal enabledelayedexpansion

set "chars=abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ01234567890123456789012345678901234567890123456789"
set "result="
for /l %%i in (1,1,25) do (
    set /a "idx=!RANDOM! %% 102"
    for %%j in (!idx!) do set "result=!result!!chars:~%%j,1!"
)

<nul set /p "=%result%" | clip

set "t=%time: =0%"
set "timestamp=%date% %t:~0,8%"

(
    echo !timestamp! !result!
    if exist "%~dp0OTP.txt" type "%~dp0OTP.txt"
) > "%~dp0OTP.tmp"
move /y "%~dp0OTP.tmp" "%~dp0OTP.txt" > nul

endlocal
exit